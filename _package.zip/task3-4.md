# CCIR TECHCAMP 2021

## TOPICS DISCUSSED SO FAR
- Programmer's Community
- Common Basics of Programming and Python Specialties
- The Python Standard Library & Further on IDEs and Utilities

## TASKSLIST

- [x] Set up your first GitHub repo
- [x] Run and Debug in VSCode within an environment in Anaconda
- [x] Create your first Jupyter Notebook!
- [x] Phase 2 Exercises
- [ ] Phase 2 Additional Exercises
- [ ] Handling JSON
- [ ] Loading files
- [ ] Database Handling
- [x] Write a Markdown
 

