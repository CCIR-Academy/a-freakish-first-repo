# inst = 'Enter the no of lines you want to print:'
# no = int(input(inst)) #no of rows
# no_s = no-1 #no of spaces in front
# for i in range(1, no+1):
#     print(" " * no_s, '* '*i)
#     no_s = no_s - 1

# inst = 'Enter the no of lines you want to print:'
# no = int(input(inst)) #no of rows
# no_s = 0 #no of spaces in front
# for i in reversed(range(1, no+1)):
#     print(" " * no_s, '* '*i)
#     no_s = no_s + 1

# people = ['a', 'b', 'c']
# for p in people:
#     print(p)

# inst = 'Enter the no of lines you want to print:'
# no = int(input(inst)) #no of rows
# no_s = no-1 #no of spaces in front
# for i in range(1, no+1):
#     print(" " * no_s, '*'*i)
#     no_s = no_s - 1
    
data = [1.618, "hi"]

number = data[0]
string = data[1]

number = int(number) + 2

if number:
     print(print( number * string ))



